package com.demo.ShoppingAdmin;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ShoppingAdminApplicationTests {

	@Test
	void contextLoads() {
	}

}
