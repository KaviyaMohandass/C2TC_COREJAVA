package com.demo.ShoppingAdmin;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class ShoppingAdminApplication {

	public static void main(String[] args) {
		SpringApplication.run(ShoppingAdminApplication.class, args);
	}

}
